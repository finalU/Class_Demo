using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    public int score = 0;
    

    

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("PickUp"))
        {
            other.gameObject.SetActive(false);
            score++;
        }
        else if(other.gameObject.CompareTag("Finish"))
        {
            if(score == 15)
            {
                other.gameObject.SetActive(false);
                
            }
        }
    }
}
